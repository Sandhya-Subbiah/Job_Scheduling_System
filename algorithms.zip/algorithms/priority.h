#ifndef priority_h
#define priority_h

#include <bits/stdc++.h>
using namespace std;


bool compare(Process a, Process b);
bool compare2(Process a, Process b);
void priority();

#endif
